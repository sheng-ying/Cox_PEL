
# A PEL approach for information synthesis


library(survival)
library(mvtnorm)
library(glmnet)



enppl <- function(x, y, delta, alpha){
  surv <- cbind(time=y, status=delta)
  cv.out <- cv.glmnet(x, y=surv, family="cox", alpha=alpha)
  out <- glmnet(x, y=surv, family="cox", alpha=alpha, lambda=cv.out$lambda.min)
  return(as.vector(out$beta))
}



ppl <- function(x, y, delta, rho, alpha){
  b.old <- enppl(x, y, delta, alpha=alpha)
  b.old[which(b.old==0)] <- 0.001
  surv <- cbind(time=y, status=delta)
  cv.out <- cv.glmnet(x, y=surv, family="cox", alpha=1, penalty.factor=1/(abs(b.old)^rho))
  out <- glmnet(x, y=surv, family="cox", alpha=1, lambda=cv.out$lambda.min, penalty.factor=1/(abs(b.old)^rho))
  return(as.vector(out$beta))
}





hazard <- function(x, y, delta, b, v, t.star, gamma){
  s0 <- sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b))})
  de <- s0 + v*sapply(y, function(u){as.integer(u<=t.star)})
  nu <- delta*sapply(y, function(u){as.integer(u<=t.star)})
  mean(nu/de) -gamma
}



psi.fun <- function(x, psi, b, gamma){
  out <- c( as.numeric(x[1]==0 & x[2]>0)*(exp(-gamma*exp(x%*%b))-psi[1]), 
            as.numeric(x[1]==0 & x[2]<0)*(exp(-gamma*exp(x%*%b))-psi[2]),
            x[1]-psi[3], x[2]-psi[4] )
  return(out)
}



ell <- function(x, y, delta, t.star, psi, b, gamma, v, xi){
  n <- nrow(x)
  d <- ncol(x)
  s0 <- sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b))})
  ell1 <- sum(delta*(x%*%b-log(s0+v*as.integer(y<=t.star)))) + n*v*gamma
  psi.ee <- apply(x,1,function(u){psi.fun(u, psi, b, gamma)})
  psi.xi <- xi%*%psi.ee
  psi.xi[which(psi.xi <= (1/n-1))] <- (1/n-1)
  psi.xi[which(psi.xi > n)] <- n
  ell2 <- sum( sapply( 1+psi.xi, function(u){log(u)} ) )
  ell <- ell2 - ell1
  return(ell)
}



# the Alasso penalty; LQA algorithm
pen <- function(b, b.ini, b.old, tau, rho){
  b.old[which(b.old==0)] <- 0.001
  b.ini[which(b.ini==0)] <- 0.001
  out <- tau*b%*%diag(1/(2*abs(b.ini)^rho*abs(b.old)))%*%b 
  return(out)
}


# an iterative algorithm for the PEL approach
pel <- function(x, y, delta, t.star, psi, tau, rho, alpha=0.1, nrep=10, threshold=0.001, tol=0.001){
  K <- length(psi)
  n <- nrow(x)
  d <- ncol(x)
  v.old <- 0
  xi.old <- rep(0, K)
  xiv.old <- c(xi.old, v.old)
  b.pl <- summary(coxph(Surv(y, delta) ~ x ))$coef[,1]
  b.en <- enppl(x, y, delta, alpha)
  b.old <- b.en
  b.ini <- b.pl
  gamma.old <- mean( (delta*sapply(y, function(u){as.integer(u<=t.star)}))/
                     (sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b.old))})) )
  gamma.ini <- mean( (delta*sapply(y, function(u){as.integer(u<=t.star)}))/
                       (sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b.ini))})) )
  theta.ini <- c(b.ini, gamma.ini)
  theta.old <- c(b.old, gamma.old)
  
  k <- 1
  while (k <= nrep){

    fxiv <- function(xiv){
      xi <- xiv[1:K]
      v <- xiv[-c(1:K)]
      ell(x, y, delta, t.star, psi, b.old, gamma.old, v, xi)
    }
    xiv.new <- optim(xiv.old, fxiv, method = "L-BFGS-B", lower=rep(-0.25,(K+1)),upper=rep(0.25,(K+1)), control = list(maxit=30,fnscale=-1))$par
    xi.new <- xiv.new[1:K]
    v.new <- xiv.new[-c(1:K)]
    
    
    ftheta <- function(theta){
      b <- theta[1:d]
      gamma <- theta[-(1:d)]
      ell(x,y,delta,t.star,psi,b,gamma,v.new,xi.new) + n*pen(b,b.ini, b.old, tau, rho)
    }
    gtheta <- function(theta){
      ttt <- t(matrix(rep(theta,length(theta)),nrow=length(theta)))+diag(length(theta))/n
      out <- n*(apply(ttt,1,ftheta) - rep(ftheta(theta),length(theta)))
      return(out)
    }
    theta.new <- optim(theta.ini, ftheta, method = "L-BFGS-B", lower=theta.ini-0.25, upper = theta.ini+0.25, control = list(maxit=100))$par
    b.new <- theta.new[1:d]
    b.new[ which(abs(b.new)<threshold) ] <- 0
    gamma.new <- theta.new[-c(1:d)]
    
    if ( max(abs(b.new - b.old) ) <= tol){break}
    k <- k+1
    b.old <- b.new
    gamma.old <- gamma.new
    xi.old <- xi.new
    v.old <- v.new
    }
  bic <- 2*ell(x,y,delta,t.star,psi,b.new,gamma.new,v.new,xi.new) + sum(b.new[-1]!=0)*log(n)*max(log(log(d)),1)
  list(b.new=b.new, bic=bic)
}





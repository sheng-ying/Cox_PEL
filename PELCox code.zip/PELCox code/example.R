
# Combining IPD and AD in Cox Regression
# Simulation Studies 

source("pel.R")
source("pelex.R")

# censoring rates: 0%, 20%, 40%
sce <- 1
if ( sce==1 ){ ucen <- c(200,210); cenp <- 0 }
if ( sce==2 ){ ucen <- c(0,5.1); cenp <- 0.2 }
if ( sce==3 ){ ucen <- c(0,2.5); cenp <- 0.4 }
d <- 15     # dimensionality of x
beta <- c(-0.3, 0.2, 0.2, rep(0,d-3) )
d0 <- sum(beta!=0)     # true number of nonzero parameters
t.star <- 0.5
gamma0 <- t.star^2
set_ex <- c(1,d)


# the external aggregated information
psi.ex <- psi <- c(0.74, 0.79, 0.5, 0)
psi.star <- c(0.74, 0.80, 0.5, -0.03)


# the individual-level data
set.seed(0)
n <- 200
x1 <- rbinom( n, 1, 0.5)  
x2 <- rnorm( n ) 
x3 <- x1*x2
x4 <- rmvnorm(n, mean = rep(0,d-d0), sigma = diag(d-d0))
x <- cbind( x1, x2, x3, x4)
t <- sapply(exp(-1*(x%*%beta)/2), rweibull, n=1, shape=2)   
cen <- runif(n, ucen[1], ucen[2])
y <- apply(cbind(t,cen),1,min)
delta <- as.numeric(t <= cen)


# the proposed PEL approaches
tau <- 0.02
rho <- 1
obj <- pel(x, y, delta, t.star, psi, tau, rho=rho)
obj.star <- pel(x, y, delta, t.star, psi.star, tau, rho=rho)
obj.ex <- pel_ex(x, y, delta, t.star, psi.ex, tau, set_ex, rho=rho)
  

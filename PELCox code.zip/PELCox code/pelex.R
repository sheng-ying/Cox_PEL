
# A PEL approach for information synthesis under population heterogeneity 


library(survival)
library(mvtnorm)
library(glmnet)



enppl <- function(x, y, delta, alpha){
  surv <- cbind(time=y, status=delta)
  cv.out <- cv.glmnet(x, y=surv, family="cox", alpha=alpha)
  out <- glmnet(x, y=surv, family="cox", alpha=alpha, lambda=cv.out$lambda.min)
  return(as.vector(out$beta))
}



ppl <- function(x, y, delta, rho, alpha){
  b.old <- enppl(x, y, delta, alpha=alpha)
  b.old[which(b.old==0)] <- 0.001
  surv <- cbind(time=y, status=delta)
  cv.out <- cv.glmnet(x, y=surv, family="cox", alpha=1, penalty.factor=1/(abs(b.old)^rho))
  out <- glmnet(x, y=surv, family="cox", alpha=1, lambda=cv.out$lambda.min, penalty.factor=1/(abs(b.old)^rho))
  return(as.vector(out$beta))
}



hazard <- function(x, y, delta, b, v, t.star, gamma){
  s0 <- sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b))})
  de <- s0 + v*sapply(y, function(u){as.integer(u<=t.star)})
  nu <- delta*sapply(y, function(u){as.integer(u<=t.star)})
  mean(nu/de) -gamma
}



psi.fun.ex <- function(x, psi, a, b, gamma, set_ex){
  zzz <- c(1, x[set_ex])
  out <- c( as.numeric(x[1]==0 & x[2]>0)*(exp(-gamma*exp(x%*%b))-psi[1]), 
            as.numeric(x[1]==0 & x[2]<0)*(exp(-gamma*exp(x%*%b))-psi[2]),
            x[1]-psi[3], x[2]-psi[4] )
  out <- as.vector(exp(zzz%*%a))*out
  return(out)
}



get.a <- function(x, psi, b, gamma, set_ex){
  fa <-function(a){
    a[1] <- -log(mean(exp(x[,set_ex]%*%a[-1])))
    f <- apply(x,1,function(u){psi.fun.ex(u, psi, a, b, gamma, set_ex)})
    sum(rowSums(f)^2)
  }
  a.ini <- optim(rep(0,(1+length(set_ex))), fa, method = "L-BFGS-B", control = list(maxit=100))$par
  return(a.ini)
}
  
  
  

# the constrained log full likelihood function
ell_ex <- function(x, y, delta, t.star, psi, a, b, gamma, v, xi0, xi, set_ex){
  n <- nrow(x)
  d <- ncol(x)
  z <- cbind(rep(1,nrow(x)), x[,set_ex])
  s0 <- sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b))})
  ss0 <- s0+v*as.integer(y<=t.star)
  ss0 <- sapply(ss0, function(u){max(u,1/n)})
  ell_ex1 <- sum(delta*(x%*%b-log(ss0))) + n*v*gamma
  
  psi.ee.ex <- apply(x,1,function(u){psi.fun.ex(u, psi, a, b, gamma, set_ex)})
  psi.xi.ex <- xi0*(exp(z%*%a)-1) + t(xi%*%psi.ee.ex)
  psi.xi.ex[which(psi.xi.ex <= (1/n-1))] <- (1/n-1)
  psi.xi.ex[which(psi.xi.ex > n)] <- n
  ell_ex2 <- sum( sapply( 1+psi.xi.ex, function(u){log(u)} ) )
  
  ell_ex <- ell_ex2 - ell_ex1
  return(ell_ex)
}



# the adaptive lasso penalty (Zou, 2006); LQA algorithm
pen <- function(b, b.ini, b.old, tau, rho){
  b.old[which(b.old==0)] <- 0.001
  b.ini[which(b.ini==0)] <- 0.001
  out <- tau*b%*%diag(1/(2*abs(b.ini)^rho*abs(b.old)))%*%b 
  return(out)
}


# an iterative algorithm for the extended PEL approach
pel_ex <- function(x, y, delta, t.star, psi, tau, set_ex, rho, alpha=0.1, nrep=10, threshold=0.001, tol=0.001){
  K <- length(psi)
  n <- nrow(x)
  d <- ncol(x)
  xi0.old <- 0
  v.old <- 0
  xi.old <- rep(0, K)
  xiv.old <- c(xi0.old, xi.old, v.old)
  b.pl <- summary(coxph(Surv(y, delta) ~ x ))$coef[,1]
  b.en <- enppl(x, y, delta, alpha)
  b.old <- b.pl 
  b.ini <- b.en 
  gamma.old <- mean( (delta*sapply(y, function(u){as.integer(u<=t.star)}))/
                       (sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b.old))})) )
  gamma.ini <- mean( (delta*sapply(y, function(u){as.integer(u<=t.star)}))/
                       (sapply(y, function(u){mean(as.integer(y>=u)*exp(x%*%b.ini))})) )
  a.old <- get.a (x, psi, b.old, gamma.old, set_ex)
  a.ini <- get.a (x, psi, b.ini, gamma.ini, set_ex)
  theta.old <- c(b.old, gamma.old, a.old)
  theta.ini <- c(b.ini, gamma.ini, a.ini)
  
  k <- 1
  while (k <= nrep){
    
    fxiv <- function(xiv){
      xi0 <- xiv[1]
      xi <- xiv[2:(K+1)]
      v <- xiv[-c(1:(K+1))]
      ell_ex(x, y, delta, t.star, psi, a.old, b.old, gamma.old, v, xi0, xi, set_ex)
    }
    xiv.new <- optim(xiv.old, fxiv, method = "L-BFGS-B", lower=rep(-0.25,(K+1)),upper=rep(0.25,(K+1)), control = list(maxit=30,fnscale=-1))$par
    xi0.new <-xiv.new[1]
    xi.new <- xiv.new[2:(K+1)]
    v.new <- xiv.new[-c(1:(K+1))]
    
    
    ftheta <- function(theta){
      b <- theta[1:d]
      gamma <- theta[(d+1)]
      a <- theta[-c(1:(d+1))]
      ell_ex(x,y,delta,t.star,psi,a,b,gamma,v.new,xi0.new,xi.new,set_ex) + n*pen(b,b.ini,b.old,tau,rho)
    }
    theta.new <- optim(theta.old, ftheta, method = "L-BFGS-B", control = list(maxit=100), lower=theta.old-0.25, upper = theta.old+0.25)$par
    b.new <- theta.new[1:d]
    b.new[ which(abs(b.new)<threshold) ] <- 0
    gamma.new <- theta.new[(d+1)]
    a.new <- theta.new[-c(1:(d+1))]
    
    
    if ( max(abs(b.new - b.old) ) <= tol){break}
    k <- k+1
    b.old <- b.new
    gamma.old <- gamma.new
    a.old <- a.new
    xi0.old <- xi0.new
    xi.old <- xi.new
    v.old <- v.new
  }
  bic.ex <- 2*ell_ex(x,y,delta,t.star,psi,a.new,b.new,gamma.new,v.new,xi0.new,xi.new,set_ex) + sum(b.new[-1]!=0)*log(n)*max(log(log(d)),1)
  list(b.new=b.new, a.new=a.new, bic.ex=bic.ex)
}




